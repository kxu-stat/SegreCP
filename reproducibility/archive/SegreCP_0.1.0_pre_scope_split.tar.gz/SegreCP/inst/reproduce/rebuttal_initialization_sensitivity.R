#!/usr/bin/env Rscript

# Reproduce the rebuttal-stage noisy CP-decomposition initialization study.
#
# The default is a short smoke run with the formal dimensions and first two
# recorded seeds. Add --full for the prespecified 20-replication, 10-sweep run.
# The driver refuses to overwrite a nonempty output directory.

args <- commandArgs(trailingOnly = TRUE)

value_flags <- c(
  "--reps", "--iterations", "--master-seed", "--dims", "--rank",
  "--kappa", "--coherence", "--noise-sd", "--signal-multiplier",
  "--rgd-step", "--cpca-split", "--bootstrap-reps", "--reference-dir",
  "--output"
)
seen_flags <- character()
position <- 1L
while (position <= length(args)) {
  flag <- args[[position]]
  if (!flag %in% c("--full", value_flags)) {
    stop("Unknown command-line argument: ", flag, call. = FALSE)
  }
  if (flag %in% seen_flags) {
    stop("Duplicate command-line argument: ", flag, call. = FALSE)
  }
  seen_flags <- c(seen_flags, flag)
  if (flag %in% value_flags) {
    if (position == length(args)) {
      stop("Missing value after ", flag, call. = FALSE)
    }
    position <- position + 2L
  } else {
    position <- position + 1L
  }
}

has_flag <- function(flag) flag %in% args
get_arg <- function(flag, default = NULL) {
  position <- match(flag, args)
  if (is.na(position)) return(default)
  if (position == length(args)) stop("Missing value after ", flag, call. = FALSE)
  args[[position + 1L]]
}

full_run <- has_flag("--full")
n_rep <- as.integer(get_arg("--reps", if (full_run) "20" else "2"))
t_max <- as.integer(get_arg("--iterations", if (full_run) "10" else "3"))
master_seed <- as.integer(get_arg("--master-seed", "20260829"))
dims <- as.integer(strsplit(get_arg("--dims", "60x30x30"), "x",
                            fixed = TRUE)[[1L]])
rank <- as.integer(get_arg("--rank", "3"))
kappa <- as.numeric(get_arg("--kappa", "30"))
coherence <- as.numeric(get_arg("--coherence", "0.5"))
noise_sd <- as.numeric(get_arg("--noise-sd", "1"))
signal_multiplier <- as.numeric(get_arg("--signal-multiplier", "3"))
rgd_step <- as.numeric(get_arg("--rgd-step", "0.5"))
cpca_split <- as.integer(strsplit(get_arg("--cpca-split", "1"), ",",
                                  fixed = TRUE)[[1L]])
bootstrap_reps <- as.integer(get_arg("--bootstrap-reps", "4000"))
reference_dir <- get_arg(
  "--reference-dir",
  system.file(
    "extdata", "rebuttal_init", "decomp_ref",
    package = "SegreCP"
  )
)
formal_settings <- full_run && n_rep == 20L && t_max == 10L &&
  master_seed == 20260829L && identical(dims, c(60L, 30L, 30L)) &&
  rank == 3L && kappa == 30 && coherence == 0.5 && noise_sd == 1 &&
  signal_multiplier == 3 && rgd_step == 0.5 &&
  identical(cpca_split, 1L) && bootstrap_reps == 4000L
run_label <- if (formal_settings) "formal" else if (full_run) "custom" else
  "smoke"
default_output <- file.path(
  getwd(),
  sprintf("SegreCP_rebuttal_decomposition_%s_seed%d", run_label, master_seed)
)
output_dir <- path.expand(get_arg("--output", default_output))

stopifnot(
  n_rep >= 1L, t_max >= 1L, master_seed > 0L,
  master_seed <= .Machine$integer.max - n_rep,
  length(dims) >= 3L, all(dims >= rank), rank >= 1L,
  kappa >= 1, coherence >= 0, coherence < 1, noise_sd >= 0,
  signal_multiplier > 0, rgd_step > 0, bootstrap_reps >= 100L,
  length(cpca_split) >= 1L,
  all(cpca_split %in% seq_along(dims)),
  length(unique(cpca_split)) == length(cpca_split),
  length(cpca_split) < length(dims)
)

if (!requireNamespace("SegreCP", quietly = TRUE)) {
  stop("Install SegreCP before running this driver.", call. = FALSE)
}
if (!requireNamespace("digest", quietly = TRUE)) {
  stop("Install the suggested package 'digest' for provenance hashes.",
       call. = FALSE)
}
reference_file <- file.path(reference_dir, "trajectory_raw.csv")
if (formal_settings && (!nzchar(reference_dir) || !file.exists(reference_file))) {
  stop(
    "The formal run requires the bundled legacy reference for its parity gate.",
    call. = FALSE
  )
}

if (dir.exists(output_dir) && length(list.files(
  output_dir, all.files = TRUE, no.. = TRUE
))) {
  stop("Refusing to overwrite nonempty output directory: ", output_dir,
       call. = FALSE)
}
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
if (!dir.exists(output_dir)) {
  stop("Could not create output directory: ", output_dir, call. = FALSE)
}

RNGkind("Mersenne-Twister", "Inversion", "Rejection")
method_order <- c("CP-ALS", "RGD", "RGN")
initialization_order <- c("CPCA", "HOSVD")

generate_coherent_vectors <- function(p, r, rho) {
  gram <- toeplitz(rho^(0:(r - 1L)))
  chol_factor <- chol(gram)
  gaussian <- matrix(stats::rnorm(p * r), nrow = p, ncol = r)
  qr.Q(qr(gaussian)) %*% chol_factor
}

make_truth <- function() {
  factors <- lapply(dims, generate_coherent_vectors,
                    r = rank, rho = coherence)
  lapply(seq_len(rank), function(i) {
    exponent <- if (rank == 1L) 0 else 0.5 - (i - 1L) / (rank - 1L)
    list(
      lambda = signal_multiplier * sqrt(rank) * kappa^exponent *
        max(dims)^(length(dims) / 4),
      U = lapply(factors, function(A) A[, i])
    )
  })
}

components_from_factors <- function(factors, weights) {
  lapply(seq_along(weights), function(i) {
    list(lambda = weights[[i]], U = lapply(factors, function(A) A[, i]))
  })
}

cp_als_path <- function(observed, init, truth, iterations) {
  factors <- lapply(seq_along(dims), function(mode) {
    do.call(cbind, lapply(init, function(component) component$U[[mode]]))
  })
  weights <- vapply(init, `[[`, numeric(1L), "lambda")
  unfolded <- lapply(seq_along(dims), function(mode) {
    rTensor::k_unfold(rTensor::as.tensor(observed), m = mode)@data
  })
  errors <- numeric(iterations + 1L)
  objective <- numeric(iterations + 1L)
  errors[[1L]] <- SegreCP::cp_relative_error(
    components_from_factors(factors, weights), truth
  )
  fitted <- SegreCP::reconstruct_cp(
    components_from_factors(factors, weights)
  )
  objective[[1L]] <- 0.5 * sum((fitted - observed)^2)
  for (iteration in seq_len(iterations)) {
    for (mode in seq_along(dims)) {
      gram <- Reduce("*", lapply(factors[-mode], crossprod))
      khatri_rao <- rTensor::khatri_rao_list(
        factors[-mode], reverse = TRUE
      )
      updated <- unfolded[[mode]] %*% khatri_rao %*% solve(gram)
      norms <- sqrt(colSums(updated * updated))
      factors[[mode]] <- sweep(updated, 2L, norms, "/")
      weights <- norms
    }
    errors[[iteration + 1L]] <- SegreCP::cp_relative_error(
      components_from_factors(factors, weights), truth
    )
    fitted <- SegreCP::reconstruct_cp(
      components_from_factors(factors, weights)
    )
    objective[[iteration + 1L]] <- 0.5 * sum((fitted - observed)^2)
  }
  list(
    components = components_from_factors(factors, weights),
    errors = errors,
    objective = objective
  )
}

legacy_hosvd_signed_weights <- function(observed) {
  factor_matrices <- lapply(seq_along(dims), function(mode) {
    permutation <- c(mode, setdiff(seq_along(dims), mode))
    unfolding <- matrix(aperm(observed, permutation), nrow = dims[[mode]])
    base::svd(unfolding, nu = rank, nv = 0L)$u[, seq_len(rank), drop = FALSE]
  })
  vapply(seq_len(rank), function(i) {
    direction <- Reduce(
      kronecker,
      rev(lapply(factor_matrices, function(A) A[, i]))
    )
    sum(as.numeric(observed) * as.numeric(direction))
  }, numeric(1L))
}

fit_path <- function(method, observed, init, truth,
                     first_sweep_order = NULL) {
  if (method == "CP-ALS") {
    elapsed <- system.time({
      result <- cp_als_path(observed, init, truth, t_max)
    })[["elapsed"]]
    return(list(
      components = result$components,
      errors = result$errors,
      objective = result$objective,
      elapsed_s = unname(elapsed)
    ))
  }

  step <- if (method == "RGD") rgd_step else 1
  run_fit <- function(start, iterations, component_order) {
    control <- SegreCP::segre_control(
      profile = "manuscript",
      max_iter = iterations,
      tolerance = 0,
      step_size = step,
      step_rule = "fixed",
      component_order = component_order
    )
    SegreCP::segre_decompose(
      observed, rank, method = tolower(method), init = start,
      control = control, keep_history = TRUE
    )
  }
  elapsed <- system.time({
    if (is.null(first_sweep_order)) {
      fit <- run_fit(init, t_max, "decreasing_weight")
      path <- SegreCP::convergence_data(fit, truth)
    } else {
      # The historical rebuttal runner ordered every HOSVD sweep by signed
      # diagonal-core weights. SegreCP uses a canonical nonnegative gauge. We
      # match the historical ordering at sweep one and then use the package's
      # deterministic decreasing-nonnegative-weight convention. Consequently,
      # this branch is a stability rerun, not an exact replay of the historical
      # gauge-dependent HOSVD trajectory.
      fit_first <- run_fit(init[first_sweep_order], 1L, "fixed")
      path_first <- SegreCP::convergence_data(fit_first, truth)
      if (t_max == 1L) {
        fit <- fit_first
        path <- path_first
      } else {
        fit <- run_fit(
          fit_first$components, t_max - 1L, "decreasing_weight"
        )
        path_later <- SegreCP::convergence_data(fit, truth)
        path <- rbind(path_first, path_later[-1L, , drop = FALSE])
        path$iteration <- 0:t_max
      }
    }
  })[["elapsed"]]
  list(
    components = fit$components,
    errors = path$relative_frobenius_error,
    objective = path$objective,
    elapsed_s = unname(elapsed)
  )
}

jobs <- vector("list", n_rep)
for (replication in seq_len(n_rep)) {
  seed <- master_seed + replication
  set.seed(seed)
  truth <- make_truth()
  truth_vector <- as.numeric(SegreCP::reconstruct_cp(truth))
  observed_vector <- truth_vector + stats::rnorm(prod(dims), sd = noise_sd)
  observed <- array(observed_vector, dim = dims)

  initializers <- list(
    CPCA = SegreCP::cp_initialize(
      observed, rank, method = "cpca", split = cpca_split
    )$comps,
    HOSVD = SegreCP::cp_initialize(observed, rank, method = "hosvd")$comps
  )
  first_sweep_orders <- list(
    CPCA = NULL,
    HOSVD = order(
      legacy_hosvd_signed_weights(observed), decreasing = TRUE
    )
  )

  trajectory_rows <- list()
  accuracy_rows <- list()
  row_id <- 0L
  for (initialization in initialization_order) {
    init <- initializers[[initialization]]
    initial_error <- SegreCP::cp_relative_error(init, truth)
    initializer_sha256 <- digest::digest(
      init, algo = "sha256", serialize = TRUE
    )
    for (method in method_order) {
      result <- fit_path(
        method, observed, init, truth,
        first_sweep_order = if (method == "CP-ALS") NULL else
          first_sweep_orders[[initialization]]
      )
      row_id <- row_id + 1L
      trajectory_rows[[row_id]] <- data.frame(
        replication = replication,
        seed = seed,
        initialization = initialization,
        method = method,
        iteration = 0:t_max,
        relative_frobenius_error = result$errors,
        objective = result$objective,
        stringsAsFactors = FALSE
      )
      accuracy_rows[[row_id]] <- data.frame(
        replication = replication,
        seed = seed,
        initialization = initialization,
        method = method,
        initializer_sha256 = initializer_sha256,
        initial_relative_frobenius_error = initial_error,
        final_relative_frobenius_error = tail(result$errors, 1L),
        elapsed_s = result$elapsed_s,
        stringsAsFactors = FALSE
      )
    }
  }
  jobs[[replication]] <- list(
    trajectory = do.call(rbind, trajectory_rows),
    accuracy = do.call(rbind, accuracy_rows),
    seed_schedule = data.frame(
      replication = replication,
      seed = seed,
      data_sha256 = digest::digest(
        list(truth = truth, observed_tensor = observed_vector),
        algo = "sha256", serialize = TRUE
      ),
      stringsAsFactors = FALSE
    )
  )
  message(sprintf("replication %d/%d complete", replication, n_rep))
}

trajectory_raw <- do.call(rbind, lapply(jobs, `[[`, "trajectory"))
accuracy_raw <- do.call(rbind, lapply(jobs, `[[`, "accuracy"))
seed_schedule <- do.call(rbind, lapply(jobs, `[[`, "seed_schedule"))

mean_ci <- function(x, seed_offset, conf = 0.95) {
  x <- x[is.finite(x)]
  set.seed(master_seed + 900000L + seed_offset)
  bootstrap_mean <- replicate(
    bootstrap_reps, mean(sample(x, size = length(x), replace = TRUE))
  )
  alpha <- (1 - conf) / 2
  bounds <- as.numeric(stats::quantile(
    bootstrap_mean, c(alpha, 1 - alpha), names = FALSE, type = 8
  ))
  c(
    mean = mean(x), sd = stats::sd(x), se = stats::sd(x) / sqrt(length(x)),
    lower = bounds[[1L]], upper = bounds[[2L]], n = length(x)
  )
}

trajectory_summary_rows <- list()
summary_id <- 0L
for (initialization in initialization_order) for (method in method_order) {
  for (iteration in 0:t_max) {
    z <- trajectory_raw[
      trajectory_raw$initialization == initialization &
        trajectory_raw$method == method &
        trajectory_raw$iteration == iteration,
    ]
    summary_id <- summary_id + 1L
    ci <- mean_ci(z$relative_frobenius_error, 1000L + summary_id)
    trajectory_summary_rows[[summary_id]] <- data.frame(
      initialization = initialization,
      method = method,
      iteration = iteration,
      error_mean = ci[["mean"]],
      error_se = ci[["se"]],
      ci_lower = ci[["lower"]],
      ci_upper = ci[["upper"]],
      n_replications = ci[["n"]],
      stringsAsFactors = FALSE
    )
  }
}
trajectory_summary <- do.call(rbind, trajectory_summary_rows)

initial_unique <- unique(accuracy_raw[c(
  "replication", "initialization", "initial_relative_frobenius_error"
)])
initialization_summary <- do.call(rbind, lapply(
  seq_along(initialization_order), function(i) {
    label <- initialization_order[[i]]
    z <- initial_unique[initial_unique$initialization == label, ]
    ci <- mean_ci(z$initial_relative_frobenius_error, 100L + i)
    data.frame(
      initialization = label,
      initial_error_mean = ci[["mean"]],
      initial_error_se = ci[["se"]],
      ci_lower = ci[["lower"]],
      ci_upper = ci[["upper"]],
      n_replications = ci[["n"]],
      stringsAsFactors = FALSE
    )
  }
))

terminal_grid <- do.call(rbind, lapply(initialization_order, function(label) {
  data.frame(
    initialization = rep(label, length(method_order)),
    method = method_order,
    stringsAsFactors = FALSE
  )
}))
terminal_summary <- do.call(rbind, lapply(
  seq_len(nrow(terminal_grid)), function(i) {
    label_init <- terminal_grid$initialization[[i]]
    label_method <- terminal_grid$method[[i]]
    z <- accuracy_raw[
      accuracy_raw$initialization == label_init &
        accuracy_raw$method == label_method,
    ]
    ci <- mean_ci(z$final_relative_frobenius_error, 200L + i)
    data.frame(
      initialization = label_init,
      method = label_method,
      final_error_mean = ci[["mean"]],
      final_error_se = ci[["se"]],
      ci_lower = ci[["lower"]],
      ci_upper = ci[["upper"]],
      n_replications = ci[["n"]],
      stringsAsFactors = FALSE
    )
  }
))

checkpoint_summary <- trajectory_summary[
  trajectory_summary$iteration %in% intersect(c(3L, 5L, 10L), 0:t_max),
  , drop = FALSE
]

paired_differences <- do.call(rbind, lapply(seq_along(method_order), function(i) {
  method <- method_order[[i]]
  cpca <- accuracy_raw[
    accuracy_raw$initialization == "CPCA" & accuracy_raw$method == method,
    c("replication", "final_relative_frobenius_error")
  ]
  hosvd <- accuracy_raw[
    accuracy_raw$initialization == "HOSVD" & accuracy_raw$method == method,
    c("replication", "final_relative_frobenius_error")
  ]
  joined <- merge(cpca, hosvd, by = "replication",
                  suffixes = c("_CPCA", "_HOSVD"))
  difference <- joined$final_relative_frobenius_error_HOSVD -
    joined$final_relative_frobenius_error_CPCA
  ci <- mean_ci(difference, 300L + i)
  data.frame(
    method = method,
    contrast = "HOSVD minus CPCA",
    mean_difference = ci[["mean"]],
    se_difference = ci[["se"]],
    ci_lower = ci[["lower"]],
    ci_upper = ci[["upper"]],
    n_pairs = ci[["n"]],
    stringsAsFactors = FALSE
  )
}))

reference_parity <- data.frame(
  status = "SKIPPED",
  reference_available = FALSE,
  compared_rows = 0L,
  cpca_max_absolute_difference = NA_real_,
  cpals_max_absolute_difference = NA_real_,
  hosvd_initial_max_absolute_difference = NA_real_,
  max_absolute_mean_trajectory_difference = NA_real_,
  max_absolute_checkpoint_difference = NA_real_,
  method_ranking_preserved = NA,
  initializer_contrast_preserved = NA,
  exact_tolerance = 1e-10,
  mean_path_tolerance = 1e-3,
  checkpoint_tolerance = 5e-4,
  passed = NA,
  stringsAsFactors = FALSE
)
reference_compatible <- n_rep <= 20L && t_max <= 10L &&
  master_seed == 20260829L && identical(dims, c(60L, 30L, 30L)) &&
  rank == 3L && kappa == 30 && coherence == 0.5 && noise_sd == 1 &&
  signal_multiplier == 3 && rgd_step == 0.5 &&
  identical(cpca_split, 1L)
if (nzchar(reference_dir) && file.exists(reference_file) &&
    reference_compatible) {
  reference <- utils::read.csv(reference_file, stringsAsFactors = FALSE)
  current <- trajectory_raw
  keys <- c("replication", "seed", "initialization", "method", "iteration")
  required_reference_columns <- c(keys, "relative_frobenius_error")
  if (!all(required_reference_columns %in% names(reference))) {
    stop("The legacy reference trajectory has an incompatible schema.",
         call. = FALSE)
  }
  reference <- reference[
    reference$replication <= n_rep &
      reference$seed == master_seed + reference$replication &
      reference$initialization %in% initialization_order &
      reference$method %in% method_order &
      reference$iteration <= t_max,
  ]
  if (!nrow(reference)) {
    stop("The legacy reference contains no rows for the requested run.",
         call. = FALSE)
  }
  current_keys <- do.call(paste, c(current[keys], sep = "|"))
  reference_keys <- do.call(paste, c(reference[keys], sep = "|"))
  unique_matching_keys <- !anyDuplicated(current_keys) &&
    !anyDuplicated(reference_keys) && setequal(current_keys, reference_keys)
  joined <- merge(
    current[c(keys, "relative_frobenius_error")],
    reference[c(keys, "relative_frobenius_error")],
    by = keys, suffixes = c("_package", "_legacy")
  )
  joined$absolute_difference <- abs(
    joined$relative_frobenius_error_package -
      joined$relative_frobenius_error_legacy
  )
  cpca_maximum <- max(joined$absolute_difference[
    joined$initialization == "CPCA"
  ])
  cpals_maximum <- max(joined$absolute_difference[
    joined$method == "CP-ALS"
  ])
  hosvd_initial_maximum <- max(joined$absolute_difference[
    joined$initialization == "HOSVD" & joined$iteration == 0L
  ])

  current_means <- aggregate(
    relative_frobenius_error ~ initialization + method + iteration,
    trajectory_raw, mean
  )
  reference_means <- aggregate(
    relative_frobenius_error ~ initialization + method + iteration,
    reference, mean
  )
  mean_joined <- merge(
    current_means, reference_means,
    by = c("initialization", "method", "iteration"),
    suffixes = c("_package", "_legacy")
  )
  mean_joined$absolute_difference <- abs(
    mean_joined$relative_frobenius_error_package -
      mean_joined$relative_frobenius_error_legacy
  )
  maximum_mean <- max(mean_joined$absolute_difference)
  checkpoint_rows <- mean_joined$iteration %in% intersect(c(3L, 5L, 10L),
                                                           0:t_max)
  maximum_checkpoint <- if (any(checkpoint_rows)) {
    max(mean_joined$absolute_difference[checkpoint_rows])
  } else 0

  ranking_signature <- function(z) {
    z <- aggregate(
      relative_frobenius_error ~ initialization + method + iteration,
      z, mean
    )
    groups <- split(
      z,
      interaction(z$initialization, z$iteration, drop = TRUE)
    )
    signature <- vapply(groups, function(group) {
      group <- group[order(group$relative_frobenius_error, group$method), ]
      paste(group$method, collapse = ">")
    }, character(1L))
    signature[order(names(signature))]
  }
  ranking_iterations <- intersect(c(3L, 5L, 10L), 0:t_max)
  if (length(ranking_iterations)) {
    package_ranking <- ranking_signature(trajectory_raw[
      trajectory_raw$iteration %in% ranking_iterations,
    ])
    legacy_ranking <- ranking_signature(reference[
      reference$iteration %in% ranking_iterations,
    ])
    ranking_preserved <- identical(package_ranking, legacy_ranking)
  } else {
    ranking_preserved <- TRUE
  }

  initialization_contrast <- function(z) {
    if (!length(ranking_iterations)) return(logical())
    means <- aggregate(
      relative_frobenius_error ~ initialization + method + iteration,
      z[z$iteration %in% ranking_iterations, ], mean
    )
    if (!nrow(means)) return(logical())
    cpca <- means[means$initialization == "CPCA",
                  c("method", "iteration", "relative_frobenius_error")]
    hosvd <- means[means$initialization == "HOSVD",
                   c("method", "iteration", "relative_frobenius_error")]
    joined_init <- merge(cpca, hosvd, by = c("method", "iteration"),
                         suffixes = c("_CPCA", "_HOSVD"))
    signature <- setNames(
      joined_init$relative_frobenius_error_HOSVD -
        joined_init$relative_frobenius_error_CPCA > 0,
      paste(joined_init$method, joined_init$iteration, sep = "|")
    )
    signature[order(names(signature))]
  }
  initializer_contrast_preserved <- if (length(ranking_iterations)) {
    identical(
      initialization_contrast(trajectory_raw),
      initialization_contrast(reference)
    )
  } else TRUE

  reference_parity <- data.frame(
    status = "CHECKED",
    reference_available = TRUE,
    compared_rows = nrow(joined),
    cpca_max_absolute_difference = cpca_maximum,
    cpals_max_absolute_difference = cpals_maximum,
    hosvd_initial_max_absolute_difference = hosvd_initial_maximum,
    max_absolute_mean_trajectory_difference = maximum_mean,
    max_absolute_checkpoint_difference = maximum_checkpoint,
    method_ranking_preserved = ranking_preserved,
    initializer_contrast_preserved = initializer_contrast_preserved,
    exact_tolerance = 1e-10,
    mean_path_tolerance = 1e-3,
    checkpoint_tolerance = 5e-4,
    passed = unique_matching_keys &&
      nrow(joined) == n_rep * 2L * 3L * (t_max + 1L) &&
      cpca_maximum <= 1e-10 && cpals_maximum <= 1e-10 &&
      hosvd_initial_maximum <= 1e-10 &&
      maximum_mean <= 1e-3 && maximum_checkpoint <= 5e-4 &&
      ranking_preserved && initializer_contrast_preserved,
    stringsAsFactors = FALSE
  )
} else if (nzchar(reference_dir) && file.exists(reference_file)) {
  reference_parity$status <- "SKIPPED_INCOMPATIBLE_SETTINGS"
}
if (formal_settings && !isTRUE(reference_parity$reference_available)) {
  stop("The formal run did not execute the required legacy parity gate.",
       call. = FALSE)
}

t0 <- trajectory_raw[trajectory_raw$iteration == 0L, ]
t0_ranges <- aggregate(
  relative_frobenius_error ~ replication + initialization,
  t0, function(x) diff(range(x))
)
mean_groups <- split(
  trajectory_summary,
  interaction(trajectory_summary$initialization, trajectory_summary$method,
              drop = TRUE)
)
mean_paths_monotone <- all(vapply(mean_groups, function(z) {
  z <- z[order(z$iteration), ]
  all(diff(z$error_mean) <= 1e-12)
}, logical(1L)))
objective_groups <- split(
  trajectory_raw,
  interaction(
    trajectory_raw$replication, trajectory_raw$initialization,
    trajectory_raw$method, drop = TRUE
  )
)
objective_paths_nonincreasing <- all(vapply(objective_groups, function(z) {
  z <- z[order(z$iteration), ]
  all(is.finite(z$objective)) && all(diff(z$objective) <= 1e-8)
}, logical(1L)))
validation_checks <- data.frame(
  check = c(
    "expected trajectory rows",
    "all oracle errors finite",
    "identical iteration-0 error across methods",
    "unique generated-data fingerprints",
    "terminal values match final trajectory rows",
    "all observed-loss trajectories non-increasing",
    "all six mean trajectories non-increasing",
    "legacy accuracy and method-ranking parity within recorded tolerances"
  ),
  passed = c(
    nrow(trajectory_raw) == n_rep * 2L * 3L * (t_max + 1L),
    all(is.finite(trajectory_raw$relative_frobenius_error)),
    all(t0_ranges$relative_frobenius_error < 1e-12),
    length(unique(seed_schedule$data_sha256)) == n_rep,
    isTRUE(all.equal(
      accuracy_raw$final_relative_frobenius_error,
      trajectory_raw$relative_frobenius_error[
        trajectory_raw$iteration == t_max
      ],
      tolerance = 1e-13, check.attributes = FALSE
    )),
    objective_paths_nonincreasing,
    mean_paths_monotone,
    !isTRUE(reference_parity$reference_available) ||
      isTRUE(reference_parity$passed)
  ),
  stringsAsFactors = FALSE
)
if (!all(validation_checks$passed)) {
  print(validation_checks, row.names = FALSE)
  stop("Validation failed; refusing to promote this run.", call. = FALSE)
}

metadata <- data.frame(
  field = c(
    "task", "run_mode", "dimensions", "rank", "condition_number",
    "coherence", "noise_sd", "signal_multiplier", "replications",
    "iterations", "master_seed", "rng_kind", "cpca_split",
    "initialization_protocol", "rgd_step", "rgn_step", "update_scheme",
    "component_order", "retraction", "uncertainty", "package_version",
    "error_metric"
  ),
  value = c(
    "rebuttal-stage noisy CP decomposition initialization sensitivity",
    run_label, paste(dims, collapse = "x"), rank, kappa, coherence, noise_sd,
    signal_multiplier, n_rep, t_max, master_seed,
    paste(RNGkind(), collapse = ";"), paste(cpca_split, collapse = ";"),
    "each realized CPCA/HOSVD object is shared by CP-ALS, RGD, and RGN",
    rgd_step, 1, "gauss_seidel",
    paste0(
      "canonical package stability rerun: historical signed HOSVD order at ",
      "sweep 1, decreasing nonnegative-weight order thereafter"
    ),
    "exact rank-(1,...,1) structured T-HOSVD",
    sprintf("percentile-bootstrap 95%% CI; B=%d", bootstrap_reps),
    as.character(utils::packageVersion("SegreCP")),
    "whole-tensor relative Frobenius reconstruction error"
  ),
  stringsAsFactors = FALSE
)

utils::write.csv(trajectory_raw, file.path(output_dir, "trajectory_raw.csv"),
                 row.names = FALSE)
utils::write.csv(trajectory_summary,
                 file.path(output_dir, "trajectory_summary.csv"),
                 row.names = FALSE)
utils::write.csv(checkpoint_summary,
                 file.path(output_dir, "checkpoint_summary.csv"),
                 row.names = FALSE)
utils::write.csv(accuracy_raw,
                 file.path(output_dir, "terminal_accuracy_raw.csv"),
                 row.names = FALSE)
utils::write.csv(initialization_summary,
                 file.path(output_dir, "initialization_summary.csv"),
                 row.names = FALSE)
utils::write.csv(terminal_summary,
                 file.path(output_dir, "terminal_summary.csv"),
                 row.names = FALSE)
utils::write.csv(paired_differences,
                 file.path(output_dir, "paired_initialization_differences.csv"),
                 row.names = FALSE)
utils::write.csv(seed_schedule,
                 file.path(output_dir, "seed_schedule_and_data_fingerprints.csv"),
                 row.names = FALSE)
utils::write.csv(metadata, file.path(output_dir, "metadata.csv"),
                 row.names = FALSE)
utils::write.csv(reference_parity,
                 file.path(output_dir, "legacy_reference_parity.csv"),
                 row.names = FALSE)
utils::write.csv(validation_checks,
                 file.path(output_dir, "validation_checks.csv"),
                 row.names = FALSE)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_path <- if (length(script_arg)) {
  normalizePath(sub("^--file=", "", script_arg[[1L]]), mustWork = TRUE)
} else NA_character_
package_dir <- system.file(package = "SegreCP")
package_provenance <- unique(c(
  file.path(package_dir, "DESCRIPTION"),
  file.path(package_dir, "NAMESPACE"),
  list.files(file.path(package_dir, "R"), full.names = TRUE),
  list.files(file.path(package_dir, "libs"), full.names = TRUE,
             recursive = TRUE)
))
reference_provenance <- file.path(
  reference_dir,
  c("trajectory_raw.csv", "metadata.csv", "source_manifest.csv")
)
manifest_paths <- c(script_path, package_provenance, reference_provenance)
manifest_roles <- c(
  "runner",
  paste0("installed_package_", basename(package_provenance)),
  paste0("legacy_reference_", basename(reference_provenance))
)
package_labels <- file.path(
  "installed_package",
  substring(package_provenance, nchar(package_dir) + 2L)
)
reference_labels <- file.path(
  "inst", "extdata", "rebuttal_init", "decomp_ref",
  basename(reference_provenance)
)
manifest_labels <- c(
  "inst/reproduce/rebuttal_initialization_sensitivity.R",
  package_labels,
  reference_labels
)
keep_manifest <- !is.na(manifest_paths) & file.exists(manifest_paths)
source_manifest <- data.frame(
  role = manifest_roles[keep_manifest],
  file = manifest_labels[keep_manifest],
  sha256 = vapply(
    manifest_paths[keep_manifest], digest::digest, character(1L),
    algo = "sha256", file = TRUE, serialize = FALSE
  ),
  stringsAsFactors = FALSE
)
utils::write.csv(source_manifest,
                 file.path(output_dir, "source_manifest.csv"),
                 row.names = FALSE)
writeLines(capture.output(sessionInfo()),
           file.path(output_dir, "sessionInfo.txt"))
writeLines(c(
  "SegreCP rebuttal-stage decomposition reproduction",
  sprintf("Mode: %s", run_label),
  sprintf("Passed: %d/%d validation checks",
          sum(validation_checks$passed), nrow(validation_checks)),
  capture.output(print(validation_checks, row.names = FALSE)),
  "",
  "The mean-trajectory checks are empirical diagnostics for this frozen",
  "design. Observed loss was non-increasing in every recorded package path,",
  "but oracle error can fluctuate near the noise floor. These diagnostics",
  "are not a proof of global convergence."
), file.path(output_dir, "VALIDATION_REPORT.txt"))

saveRDS(list(
  metadata = metadata,
  seed_schedule = seed_schedule,
  trajectory_raw = trajectory_raw,
  trajectory_summary = trajectory_summary,
  checkpoint_summary = checkpoint_summary,
  terminal_accuracy_raw = accuracy_raw,
  initialization_summary = initialization_summary,
  terminal_summary = terminal_summary,
  paired_initialization_differences = paired_differences,
  reference_parity = reference_parity,
  validation_checks = validation_checks,
  source_manifest = source_manifest,
  session_info = sessionInfo()
), file.path(output_dir, "rebuttal_decomposition_reproduction.rds"))

artifact_files <- list.files(output_dir, full.names = TRUE)
artifact_files <- artifact_files[basename(artifact_files) != "artifact_manifest.csv"]
artifact_manifest <- data.frame(
  file = basename(artifact_files),
  bytes = file.info(artifact_files)$size,
  sha256 = vapply(
    artifact_files, digest::digest, character(1L),
    algo = "sha256", file = TRUE, serialize = FALSE
  ),
  stringsAsFactors = FALSE
)
utils::write.csv(artifact_manifest,
                 file.path(output_dir, "artifact_manifest.csv"),
                 row.names = FALSE)

cat("\nValidation checks:\n")
print(validation_checks, row.names = FALSE)
cat("\nLegacy reference parity:\n")
print(reference_parity, row.names = FALSE)
cat("\nTerminal summary:\n")
print(terminal_summary, row.names = FALSE, digits = 6L)
cat("\nSaved reproducible run to:\n", normalizePath(output_dir), "\n")
