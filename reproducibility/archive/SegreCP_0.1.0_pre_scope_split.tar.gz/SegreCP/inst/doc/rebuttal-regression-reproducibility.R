## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.align = "center",
  fig.retina = 2
)

data_candidates <- c(
  file.path("inst", "extdata", "rebuttal_tensor_regression"),
  file.path("..", "inst", "extdata", "rebuttal_tensor_regression"),
  system.file(
    "extdata", "rebuttal_tensor_regression", package = "SegreCP"
  )
)
data_candidates <- data_candidates[nzchar(data_candidates)]
existing_candidates <- data_candidates[dir.exists(data_candidates)]
if (!length(existing_candidates)) {
  stop("Cannot locate the frozen rebuttal tensor-regression data.")
}
data_dir <- normalizePath(existing_candidates[[1L]], mustWork = TRUE)

read_rebuttal_csv <- function(filename) {
  path <- file.path(data_dir, filename)
  if (!file.exists(path)) stop("Missing frozen artifact: ", filename)
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)
}

settings <- read_rebuttal_csv("final_settings.csv")
recorded_checks <- read_rebuttal_csv("final_validation_checks.csv")
source_manifest <- read_rebuttal_csv("final_source_artifact_sha256.csv")
checkpoint_manifest <- read_rebuttal_csv("checkpoint_source_manifest.csv")
grid_raw <- read_rebuttal_csv("final_seven_method_grid_raw.csv")
checkpoint_raw <- read_rebuttal_csv("checkpoint_metrics_raw.csv")
timing_raw <- read_rebuttal_csv(
  "final_seven_method_serial_timing_raw.csv"
)

method_order <- c(
  "CP-ALS", "RRR", "Tucker-RGD", "HOPLS", "TT-IHT", "RGD", "RGN"
)
checkpoint_methods <- setdiff(method_order, "HOPLS")
iterative_methods <- setdiff(method_order, "HOPLS")

method_colors <- c(
  "CP-ALS" = "#303030",
  "RRR" = "#858585",
  "Tucker-RGD" = "#686868",
  "HOPLS" = "#A3A3A3",
  "TT-IHT" = "#B5B5B5",
  "RGD" = "#D55E00",
  "RGN" = "#0072B2"
)
method_points <- c(
  "CP-ALS" = 15,
  "RRR" = 1,
  "Tucker-RGD" = 0,
  "HOPLS" = 5,
  "TT-IHT" = 2,
  "RGD" = 17,
  "RGN" = 16
)
method_lines <- c(
  "CP-ALS" = 3,
  "RRR" = 4,
  "Tucker-RGD" = 5,
  "HOPLS" = 6,
  "TT-IHT" = 6,
  "RGD" = 2,
  "RGN" = 1
)

metric_columns <- c(
  "coefficient_error", "train_rmse", "test_rmse",
  "clean_test_rmse", "relative_prediction_error"
)

# Balance the 12 coherence/noise cells within each replication before taking
# a mean and Monte Carlo standard error across replications. This is the
# aggregation used for the rebuttal's across-grid panel.
replication_balanced <- stats::aggregate(
  grid_raw[metric_columns],
  grid_raw[c("display_method", "replication")],
  mean
)
accuracy_mean <- stats::aggregate(
  replication_balanced[metric_columns],
  replication_balanced["display_method"],
  mean
)
accuracy_se <- stats::aggregate(
  replication_balanced[metric_columns],
  replication_balanced["display_method"],
  function(x) stats::sd(x) / sqrt(length(x))
)
names(accuracy_se)[-1L] <- paste0(names(accuracy_se)[-1L], "_se")
accuracy_summary <- merge(
  accuracy_mean, accuracy_se, by = "display_method", sort = FALSE
)
accuracy_summary <- accuracy_summary[
  match(method_order, accuracy_summary$display_method),
]

checkpoint_mean <- stats::aggregate(
  checkpoint_raw["coefficient_error"],
  checkpoint_raw[c("method", "iteration")],
  mean
)
checkpoint_se <- stats::aggregate(
  checkpoint_raw["coefficient_error"],
  checkpoint_raw[c("method", "iteration")],
  function(x) stats::sd(x) / sqrt(length(x))
)
names(checkpoint_mean)[3L] <- "error_mean"
names(checkpoint_se)[3L] <- "error_se"
checkpoint_summary <- merge(
  checkpoint_mean, checkpoint_se,
  by = c("method", "iteration"), sort = FALSE
)
checkpoint_summary$ci_lower <- NA_real_
checkpoint_summary$ci_upper <- NA_real_
for (row_id in seq_len(nrow(checkpoint_summary))) {
  row <- checkpoint_summary[row_id, ]
  values <- checkpoint_raw$coefficient_error[
    checkpoint_raw$method == row$method &
      checkpoint_raw$iteration == row$iteration
  ]
  set.seed(20260829L + 800000L + row_id)
  bootstrap_means <- replicate(
    2000L,
    mean(sample(values, size = length(values), replace = TRUE))
  )
  checkpoint_summary$ci_lower[[row_id]] <- stats::quantile(
    bootstrap_means, 0.025, names = FALSE, type = 8
  )
  checkpoint_summary$ci_upper[[row_id]] <- stats::quantile(
    bootstrap_means, 0.975, names = FALSE, type = 8
  )
}

high_raw <- grid_raw[grid_raw$coherence == 0.75, ]
high_mean <- stats::aggregate(
  high_raw["clean_test_rmse"],
  high_raw[c("display_method", "noise_sd")],
  mean
)
high_se <- stats::aggregate(
  high_raw["clean_test_rmse"],
  high_raw[c("display_method", "noise_sd")],
  function(x) stats::sd(x) / sqrt(length(x))
)
names(high_mean)[3L] <- "rmse_mean"
names(high_se)[3L] <- "rmse_se"
high_summary <- merge(
  high_mean, high_se,
  by = c("display_method", "noise_sd"), sort = FALSE
)

timing_mean <- stats::aggregate(
  timing_raw["reported_fit_sec"], timing_raw["display_method"], mean
)
timing_se <- stats::aggregate(
  timing_raw["reported_fit_sec"], timing_raw["display_method"],
  function(x) stats::sd(x) / sqrt(length(x))
)
names(timing_mean)[2L] <- "time_mean"
names(timing_se)[2L] <- "time_se"
timing_summary <- merge(
  timing_mean, timing_se, by = "display_method", sort = FALSE
)
timing_summary <- timing_summary[
  match(method_order, timing_summary$display_method),
]

summary_with_time <- merge(
  accuracy_summary, timing_summary, by = "display_method", sort = FALSE
)
summary_with_time <- summary_with_time[
  match(method_order, summary_with_time$display_method),
]

grid_pair_counts <- table(
  grid_raw$coherence, grid_raw$noise_sd, grid_raw$replication
)
grid_seed_counts <- stats::aggregate(
  grid_raw["seed"],
  grid_raw[c("coherence", "noise_sd", "replication")],
  function(x) length(unique(x))
)
checkpoint_counts <- table(
  checkpoint_raw$method, checkpoint_raw$iteration
)
checkpoint_winners <- vapply(c(3, 5, 10), function(iteration) {
  z <- checkpoint_summary[checkpoint_summary$iteration == iteration, ]
  z$method[[which.min(z$error_mean)]]
}, character(1L))
checkpoint_means_decrease <- all(vapply(
  split(checkpoint_summary, checkpoint_summary$method),
  function(z) {
    z <- z[order(z$iteration), ]
    all(diff(z$error_mean) < 0)
  },
  logical(1L)
))
high_rank_is_reproduced <- all(vapply(c(0, 0.5, 1), function(noise) {
  z <- high_summary[high_summary$noise_sd == noise, ]
  ranked <- z$display_method[order(z$rmse_mean)]
  if (noise == 0) {
    identical(ranked[[1L]], "Tucker-RGD")
  } else {
    setequal(ranked[1:2], c("RGD", "RGN"))
  }
}, logical(1L)))
accuracy_pair_is_reproduced <-
  setequal(
    accuracy_summary$display_method[
      order(accuracy_summary$coefficient_error)[1:2]
    ],
    c("RGD", "RGN")
  ) &&
  setequal(
    accuracy_summary$display_method[
      order(accuracy_summary$clean_test_rmse)[1:2]
    ],
    c("RGD", "RGN")
  )

recomputed_checks <- data.frame(
  check = c(
    "1,680 paired grid rows",
    "exact seven-method set",
    "complete 4 x 3 x 20 x 7 grid",
    "one seed per paired cell",
    "finite accuracy metrics",
    "fixed ten-update budget for iterative methods",
    "360 complete checkpoint rows",
    "checkpoint means and winners reproduce Panel A",
    "high-coherence winners reproduce Panel B",
    "RGD/RGN reproduce the across-grid accuracy pair",
    "140 serial timing rows at rho=0.5, sigma=0.5",
    "all recorded source validations passed"
  ),
  passed = c(
    nrow(grid_raw) == 1680L,
    identical(sort(unique(grid_raw$display_method)), sort(method_order)),
    identical(dim(grid_pair_counts), c(4L, 3L, 20L)) &&
      all(grid_pair_counts == 7L),
    all(grid_seed_counts$seed == 1L),
    all(vapply(grid_raw[metric_columns], function(x) all(is.finite(x)),
               logical(1L))),
    all(grid_raw$attempted_iterations[
      grid_raw$display_method %in% iterative_methods
    ] == 10L) &&
      all(grid_raw$accepted_iterations[
        grid_raw$display_method %in% iterative_methods
      ] == 10L),
    nrow(checkpoint_raw) == 360L &&
      identical(sort(unique(checkpoint_raw$method)),
                sort(checkpoint_methods)) &&
      all(checkpoint_counts == 20L),
    checkpoint_means_decrease &&
      identical(checkpoint_winners, c("RGN", "RGN", "CP-ALS")),
    high_rank_is_reproduced,
    accuracy_pair_is_reproduced,
    nrow(timing_raw) == 140L &&
      all(timing_raw$coherence == 0.5) &&
      all(timing_raw$noise_sd == 0.5) &&
      all(table(timing_raw$display_method) == 20L),
    all(recorded_checks$passed)
  ),
  stringsAsFactors = FALSE
)

runtime <- stats::setNames(
  timing_summary$time_mean, timing_summary$display_method
)
runtime_tier_order_holds <-
  max(runtime[c("RGD", "RGN")]) < runtime[["CP-ALS"]] &&
  runtime[["CP-ALS"]] < runtime[["HOPLS"]] &&
  runtime[["HOPLS"]] < runtime[["TT-IHT"]] &&
  runtime[["TT-IHT"]] < min(runtime[c("RRR", "Tucker-RGD")])

stopifnot(all(recomputed_checks$passed), runtime_tier_order_holds)

## ----settings-table, echo=FALSE-----------------------------------------------
knitr::kable(
  settings,
  col.names = c("Design item", "Frozen value"),
  align = c("l", "l")
)

## ----integrity-table, echo=FALSE----------------------------------------------
knitr::kable(
  recomputed_checks,
  col.names = c("Check recomputed in this vignette", "Passed"),
  align = c("l", "c")
)

## ----checkpoint-figure, echo=FALSE, fig.width=8.6, fig.height=5.6, fig.cap="Noiseless optimization checkpoints. Points are means over 20 paired replications; bars are deterministic 95% percentile-bootstrap intervals for the mean. The y axis is logarithmic."----
plot_checkpoint_figure <- function() {
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par))
  graphics::par(mar = c(7.4, 5.2, 3.5, 1.4), xpd = FALSE)

  lower <- checkpoint_summary$ci_lower
  upper <- checkpoint_summary$ci_upper
  y_limits <- range(c(lower, upper)) * c(0.7, 1.4)

  graphics::plot(
    NA_real_, NA_real_,
    xlim = c(2.6, 10.4), ylim = y_limits, log = "y",
    xaxt = "n", xlab = "Recorded outer-update checkpoint",
    ylab = "Relative coefficient error",
    main = "Noiseless optimization checkpoints"
  )
  graphics::axis(1, at = c(3, 5, 10))
  graphics::abline(
    h = 10^seq(floor(log10(y_limits[[1L]])),
               ceiling(log10(y_limits[[2L]]))),
    col = "#E8E8E8", lwd = 0.8
  )
  graphics::mtext(
    "rho = 0.5; sigma = 0; 20 paired replications",
    side = 3, line = 0.45, cex = 0.82, col = "#4A4A4A"
  )

  draw_order <- c("RRR", "TT-IHT", "Tucker-RGD", "CP-ALS", "RGD", "RGN")
  for (method in draw_order) {
    z <- checkpoint_summary[checkpoint_summary$method == method, ]
    z <- z[order(z$iteration), ]
    lo <- z$ci_lower
    hi <- z$ci_upper
    graphics::segments(
      z$iteration, lo, z$iteration, hi,
      col = method_colors[[method]], lwd = 1
    )
    graphics::segments(
      z$iteration - 0.07, lo, z$iteration + 0.07, lo,
      col = method_colors[[method]], lwd = 1
    )
    graphics::segments(
      z$iteration - 0.07, hi, z$iteration + 0.07, hi,
      col = method_colors[[method]], lwd = 1
    )
    graphics::lines(
      z$iteration, z$error_mean,
      col = method_colors[[method]], lty = method_lines[[method]],
      lwd = if (method %in% c("RGD", "RGN")) 2.1 else 1.35
    )
    graphics::points(
      z$iteration, z$error_mean,
      col = method_colors[[method]], pch = method_points[[method]],
      cex = if (method %in% c("RGD", "RGN")) 1.05 else 0.9,
      lwd = 1.2
    )
  }

  graphics::par(xpd = NA)
  legend_order <- c("RGN", "RGD", "CP-ALS", "Tucker-RGD", "TT-IHT", "RRR")
  user_coordinates <- graphics::par("usr")
  legend_y <- 10^(
    user_coordinates[[3L]] -
      0.25 * (user_coordinates[[4L]] - user_coordinates[[3L]])
  )
  graphics::legend(
    x = mean(c(2.6, 10.4)), y = legend_y,
    xjust = 0.5, yjust = 1, horiz = TRUE,
    legend = legend_order,
    col = method_colors[legend_order], pch = method_points[legend_order],
    lty = method_lines[legend_order],
    lwd = c(2.1, 2.1, rep(1.35, 4)),
    pt.cex = 0.85, cex = 0.72, bty = "n"
  )
}

plot_checkpoint_figure()

## ----high-coherence-figure, echo=FALSE, fig.width=11.2, fig.height=4.8, fig.cap="High-coherence clean-test RMSE. Points are means over 20 paired replications; horizontal bars are mean plus or minus 1.96 Monte Carlo standard errors. All panels share a logarithmic x scale."----
plot_high_coherence_figure <- function() {
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par))
  graphics::par(mfrow = c(1, 3), oma = c(3.2, 0, 3.2, 0))

  lower <- pmax(
    high_summary$rmse_mean - 1.96 * high_summary$rmse_se,
    .Machine$double.xmin
  )
  upper <- high_summary$rmse_mean + 1.96 * high_summary$rmse_se
  x_limits <- range(c(lower, upper)) * c(0.75, 1.3)
  display_order <- method_order
  y_position <- rev(seq_along(display_order))
  names(y_position) <- display_order

  for (panel in seq_along(c(0, 0.5, 1))) {
    noise <- c(0, 0.5, 1)[[panel]]
    z <- high_summary[high_summary$noise_sd == noise, ]
    z <- z[match(display_order, z$display_method), ]
    graphics::par(mar = c(3.9, if (panel == 1L) 7.2 else 1.1, 2.4, 1.0))
    graphics::plot(
      NA_real_, NA_real_,
      xlim = x_limits, ylim = c(0.5, length(display_order) + 0.5),
      log = "x", yaxt = "n", ylab = "", xlab = "",
      main = paste0("sigma = ", format(noise, trim = TRUE))
    )
    if (panel == 1L) {
      graphics::axis(
        2, at = y_position, labels = display_order,
        las = 1, tick = FALSE, cex.axis = 0.78
      )
    }
    graphics::abline(v = 10^(-6:-2), col = "#ECECEC", lwd = 0.8)
    lo <- pmax(z$rmse_mean - 1.96 * z$rmse_se,
               .Machine$double.xmin)
    hi <- z$rmse_mean + 1.96 * z$rmse_se
    y <- unname(y_position[z$display_method])
    graphics::segments(lo, y, hi, y,
                       col = method_colors[z$display_method], lwd = 1.2)
    graphics::segments(lo, y - 0.08, lo, y + 0.08,
                       col = method_colors[z$display_method], lwd = 1)
    graphics::segments(hi, y - 0.08, hi, y + 0.08,
                       col = method_colors[z$display_method], lwd = 1)
    graphics::points(
      z$rmse_mean, y,
      col = method_colors[z$display_method],
      pch = method_points[z$display_method], cex = 0.95, lwd = 1.2
    )
  }

  graphics::mtext(
    "High-coherence clean-test RMSE",
    side = 3, outer = TRUE, line = 1.55, cex = 1.05, font = 2
  )
  graphics::mtext(
    "rho = 0.75; 20 paired replications per noise level",
    side = 3, outer = TRUE, line = 0.3, cex = 0.82, col = "#4A4A4A"
  )
  graphics::mtext(
    "Clean-test RMSE (log scale)",
    side = 1, outer = TRUE, line = 1.45, cex = 0.88
  )
}

plot_high_coherence_figure()

## ----reproduced-table, echo=FALSE---------------------------------------------
reproduced_table <- data.frame(
  Method = summary_with_time$display_method,
  `Coefficient error` = formatC(
    summary_with_time$coefficient_error, format = "e", digits = 4
  ),
  `Clean RMSE` = formatC(
    summary_with_time$clean_test_rmse, format = "e", digits = 5
  ),
  `Noisy RMSE` = formatC(
    summary_with_time$test_rmse, format = "e", digits = 5
  ),
  `Reference time (s)` = formatC(
    summary_with_time$time_mean, format = "f", digits = 3
  ),
  check.names = FALSE
)
knitr::kable(reproduced_table, align = c("l", "r", "r", "r", "r"))

## ----tradeoff-figure, echo=FALSE, fig.width=10.2, fig.height=5.1, fig.cap="Cell-balanced accuracy and reference-machine fit time. Accuracy means and standard errors are computed across 20 replication-balanced summaries; time means and standard errors use 20 serial fits at rho = 0.5 and sigma = 0.5. The time axis is logarithmic."----
plot_tradeoff_figure <- function() {
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par))
  graphics::par(mfrow = c(1, 2), oma = c(3.3, 0, 3.5, 0))

  label_position <- c(
    "CP-ALS" = 4, "RRR" = 3, "Tucker-RGD" = 4,
    "HOPLS" = 2, "TT-IHT" = 2, "RGD" = 4, "RGN" = 2
  )
  panels <- list(
    list(
      metric = "coefficient_error", se = "coefficient_error_se",
      label = "Relative coefficient error"
    ),
    list(
      metric = "clean_test_rmse", se = "clean_test_rmse_se",
      label = "Clean-test RMSE"
    )
  )

  for (panel in panels) {
    y <- summary_with_time[[panel$metric]]
    y_se <- summary_with_time[[panel$se]]
    y_lo <- pmax(y - 1.96 * y_se, 0)
    y_hi <- y + 1.96 * y_se
    y_padding <- diff(range(c(y_lo, y_hi))) * 0.08
    y_limits <- range(c(y_lo, y_hi)) + c(-y_padding, y_padding)
    x <- summary_with_time$time_mean
    x_lo <- pmax(x - 1.96 * summary_with_time$time_se,
                 .Machine$double.xmin)
    x_hi <- x + 1.96 * summary_with_time$time_se

    graphics::par(mar = c(4.0, 5.0, 2.0, 1.2))
    graphics::plot(
      NA_real_, NA_real_, xlim = c(0.075, 7.5), ylim = y_limits,
      log = "x", xlab = "", ylab = panel$label
    )
    graphics::abline(v = c(0.1, 0.2, 0.5, 1, 2),
                     col = "#ECECEC", lwd = 0.8)
    graphics::abline(h = pretty(y_limits), col = "#F0F0F0", lwd = 0.8)
    graphics::segments(
      x_lo, y, x_hi, y,
      col = method_colors[summary_with_time$display_method], lwd = 1
    )
    graphics::segments(
      x, y_lo, x, y_hi,
      col = method_colors[summary_with_time$display_method], lwd = 1
    )
    graphics::points(
      x, y,
      col = method_colors[summary_with_time$display_method],
      pch = method_points[summary_with_time$display_method],
      cex = 1.0, lwd = 1.2
    )
    graphics::text(
      x, y, labels = summary_with_time$display_method,
      pos = unname(label_position[summary_with_time$display_method]),
      offset = 0.42, cex = 0.72,
      col = method_colors[summary_with_time$display_method]
    )
  }

  graphics::mtext(
    "Cell-balanced accuracy and reference-machine fit time",
    side = 3, outer = TRUE, line = 1.75, cex = 1.05, font = 2
  )
  graphics::mtext(
    "Lower and further left is better; means plus or minus 1.96 Monte Carlo standard errors",
    side = 3, outer = TRUE, line = 0.45, cex = 0.8, col = "#4A4A4A"
  )
  graphics::mtext(
    "Mean fit time in seconds on the reference machine (log scale)",
    side = 1, outer = TRUE, line = 1.5, cex = 0.88
  )
}

plot_tradeoff_figure()

## ----runtime-tier-table, echo=FALSE-------------------------------------------
runtime_tiers <- data.frame(
  Tier = 1:5,
  Methods = c(
    "RGD and RGN",
    "CP-ALS",
    "HOPLS",
    "TT-IHT",
    "RRR and Tucker-RGD"
  ),
  stringsAsFactors = FALSE
)
knitr::kable(
  runtime_tiers,
  col.names = c("Runtime tier (fast to slow)", "Methods"),
  align = c("c", "l")
)

