## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")
library(SegreCP)

## -----------------------------------------------------------------------------
segre_control(profile = "manuscript", max_iter = 20)

## -----------------------------------------------------------------------------
segre_control(profile = "practical", max_iter = 20)

## -----------------------------------------------------------------------------
dims <- c(3, 4, 5)
factors <- lapply(dims, function(p) diag(p)[, 1:2, drop = FALSE])
truth <- cp_components(c(3, 1.5), factors)
x <- reconstruct_cp(truth)

init_cpca <- cp_initialize(x, rank = 2, method = "cpca", split = 1)
init_hosvd <- cp_initialize(x, rank = 2, method = "hosvd")

cp_relative_error(init_cpca$comps, truth)
cp_relative_error(init_hosvd$comps, truth)

## -----------------------------------------------------------------------------
custom_init <- function(x, rank, supplied) supplied
fit <- segre_decompose(
  x, rank = 2, method = "rgn",
  init = custom_init,
  init_args = list(supplied = truth),
  control = segre_control(max_iter = 2)
)
fit

