# Release provenance

`PACKAGE_SOURCE_MANIFEST.csv` records portable SHA-256 hashes for the R, C++,
test, vignette, reproduction-driver, help, workflow, and release-documentation
files in this source package. Each rebuttal extdata directory has a separate
package-subset manifest. The built source tarball is accompanied by an external
`.sha256` file because a tarball cannot contain its own final hash.

The current workspace is not an initialized Git repository, so this snapshot
does not yet have a repository URL, commit, or immutable tag. Before a public
GitHub release, the authors should select the license, replace the `OWNER`
installation placeholders, add `URL` and `BugReports` to `DESCRIPTION`, create
an immutable tag, and attach the source tarball plus its checksum.

## Historical rebuttal source boundary

The seven-method tensor-regression archive records the SHA-256 of the exact
historical runner and solver. The current active solver was edited after that
freeze, and an exact copy of the historical solver is not present in this
workspace. Therefore SegreCP makes two narrower, testable claims:

1. the rebuttal table and figures are deterministically reconstructed from the
   paired frozen raw records and their manifests; and
2. the public RGD/RGN implementation is independently checked against direct
   numerical oracles and a fresh formal decomposition-initialization rerun.

It does not claim that the complete seven-method raw archive can be regenerated
bit-for-bit from a silently substituted later solver file. An immutable public
revision containing the exact historical source would be needed for that
stronger claim.
