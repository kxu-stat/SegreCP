# SegreCP 0.1.0

- Added sequential RGD and RGN for CP decomposition, scalar-on-tensor
  regression, and tensor-on-tensor regression.
- Added exact structured rank-`(1, ..., 1)` T-HOSVD retraction kernels.
- Added CPCA, HOSVD, random, supplied-component, and custom-function
  initialization routes.
- Added base R array/matrix, list-of-tensors, and `rTensor::Tensor`
  compatibility.
- Added manuscript and practical control profiles, documentation, vignettes,
  and direct numerical-oracle tests.
- Added optional component-history recording and `convergence_data()` for
  observed-objective and simulated-truth trajectories.
- Added frozen replicate-level rebuttal artifacts, a deterministic seven-method
  table validator, and a formal CPCA/HOSVD initialization rerun with SHA-256
  provenance and legacy-parity gates.
- Added vignettes that visualize the rebuttal-stage regression tables,
  initialization sensitivity, complete ten-sweep trajectories, and
  objective convergence. Runtime validation uses separated tiers rather than
  hardware-specific seconds or within-near-tie ordering.
